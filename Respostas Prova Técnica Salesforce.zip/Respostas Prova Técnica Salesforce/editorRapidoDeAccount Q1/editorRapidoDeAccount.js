import { LightningElement, api, wire, track } from 'lwc';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import TYPE_FIELD from '@salesforce/schema/Account.Type';

export default class EditorRapidoDeAccount extends LightningElement {
    @api recordId;
    @track accountName = '';
    @track accountNumber = '';
    @track accountType = '';
    objectInfo;

    // Carregar dados da conta e informações do objeto ao inicializar o componente
    @wire(getRecord, { recordId: '$recordId', fields: [TYPE_FIELD, 'Account.Name', 'Account.AccountNumber'] })
    loadAccount({ error, data }) {
        if (data) {
            this.accountName = getFieldValue(data, 'Account.Name');
            this.accountNumber = getFieldValue(data, 'Account.AccountNumber');
            this.accountType = getFieldValue(data, TYPE_FIELD);
        } else if (error) {
            // Lógica para lidar com erros ao carregar dados da conta
        }
    }

    @wire(getObjectInfo, { objectApiName: ACCOUNT_OBJECT })
    objectInfo;

    // Manipuladores de eventos para rastrear as alterações nos campos
    handleNameChange(event) {
        this.accountName = event.target.value;
    }

    handleNumberChange(event) {
        this.accountNumber = event.target.value;
    }

    handleTypeChange(event) {
        this.accountType = event.detail.value;
    }

    // Lógica para atualizar os campos padrões da conta
    updateAccount() {
        const fields = {};
        fields[TYPE_FIELD.fieldApiName] = this.accountType;
        fields['Name'] = this.accountName;
        fields['AccountNumber'] = this.accountNumber;

        const recordInput = { fields, apiName: ACCOUNT_OBJECT.objectApiName, Id: this.recordId };
        updateRecord(recordInput)
            .then(() => {
                // Lógica para lidar com a atualização bem-sucedida
            })
            .catch(error => {
                // Lógica para lidar com erros na atualização
            });
    }

    // Evento para acionar a atualização da conta
    handleSave() {
        this.updateAccount();
    }

    get accountTypeOptions() {
        // Obter opções de seleção do campo Type do objeto Account
        const fieldInfo = this.objectInfo.data.fields.Type;
        if (fieldInfo && fieldInfo.picklistValues) {
            return fieldInfo.picklistValues.map(option => ({
                label: option.label,
                value: option.value
            }));
        }
        return [];
    }
}
